package Ejercicio3B;

public interface Comision {

    double calcularComision();
    
}
