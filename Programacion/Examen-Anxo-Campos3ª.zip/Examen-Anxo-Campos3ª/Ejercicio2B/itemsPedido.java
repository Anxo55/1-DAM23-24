package Ejercicio2B;

public class itemsPedido {

}
