package Biblioteca;

public class MainTest {
	public static void main(String[] args) {
		EjercicioBibliotecas ej = new EjercicioBibliotecas();
		ej.iniciarEjercicio();
	}

}
